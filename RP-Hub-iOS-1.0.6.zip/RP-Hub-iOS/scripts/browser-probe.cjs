/* Optional real-browser probe. NOT part of `npm test` / CI (those run on a
 * macOS runner with no browser). Run locally with `npm run test:browser` when
 * playwright + Chromium are available.
 *
 * Verifies the riskiest assumption of the "keep keyboard up" fix: cancelling
 * mousedown's default (to keep the textarea as first responder) must NOT
 * cancel the click event, or the send button would stop working. A vm-based
 * unit test cannot prove this; only a real DOM can.
 */
const fs = require('node:fs');
const path = require('node:path');

function loadChromium() {
    const candidates = [
        'playwright',
        '/root/.nvm/versions/node/v22.13.1/lib/node_modules/playwright',
        '/usr/lib/node_modules/playwright'
    ];
    for (const c of candidates) {
        try { return require(c).chromium; } catch (_) { }
    }
    console.log('跳过：本机没有 playwright + Chromium（此探针不在 CI 里跑，不影响构建）');
    process.exit(0);
}

const chromium = loadChromium();
const root = path.resolve(__dirname, '..');
const bridge = fs.readFileSync(path.join(root, 'public', 'assets', 'js', 'capacitor-bridge.js'), 'utf8');

// The Capacitor mock MUST be inline in the HTML: page.setContent() does not
// reliably re-run addInitScript, and the bridge returns early on web platforms.
const html = `<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">
<script>window.Capacitor={isNativePlatform:()=>true,getPlatform:()=>'ios',Plugins:{Keyboard:{addListener:()=>{}}}};</script>
</head><body>
<div class="input-area-mobile"><div class="input-island">
  <textarea id="box" class="island-input"></textarea>
  <div class="island-toolbar">
    <button id="send" class="island-send">发送</button>
    <button id="img" class="island-button">图片</button>
  </div>
</div></div>
<button id="outside">外部按钮</button>
</body></html>`;

(async () => {
    const browser = await chromium.launch({
        executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium',
        headless: true,
        args: ['--no-sandbox']
    });
    const page = await browser.newPage();
    await page.setContent(html);
    await page.addScriptTag({ content: bridge });

    const diag = await page.evaluate(() => !!document.documentElement.dataset.rphubNative);
    if (!diag) { console.error('桥未以原生模式启动（mock 失效），探针无效'); await browser.close(); process.exit(1); }

    await page.evaluate(() => {
        window.__clicks = {};
        ['send', 'img', 'outside'].forEach(id => {
            document.getElementById(id).addEventListener('click', () => { window.__clicks[id] = (window.__clicks[id] || 0) + 1; });
        });
        window.__md = {};
        document.addEventListener('mousedown', e => { window.__md[e.target.id || 'x'] = e.defaultPrevented; }, false);
    });

    const r = {};
    await page.focus('#box');
    await page.click('#send');
    r['发送按钮 click 正常派发'] = await page.evaluate(() => window.__clicks.send === 1);
    r['发送按钮 mousedown 被取消（保焦）'] = await page.evaluate(() => window.__md.send === true);
    r['textarea 保持焦点（键盘不收）'] = await page.evaluate(() => document.activeElement?.id === 'box');

    await page.click('#img');
    r['图片按钮 click 正常派发'] = await page.evaluate(() => window.__clicks.img === 1);

    await page.click('#outside');
    r['外部按钮 click 正常派发'] = await page.evaluate(() => window.__clicks.outside === 1);
    r['外部按钮 mousedown 未被拦截'] = await page.evaluate(() => window.__md.outside === false);

    r['通配滤镜规则为原生常驻'] = await page.evaluate(() => {
        const s = document.getElementById('rphub-native-shell-css');
        return !!s && /html\[data-rphub-native="true"\] \*\{-webkit-backdrop-filter:none/.test(s.textContent)
            && !/rphub-keyboard-active \*\{-webkit-backdrop-filter/.test(s.textContent);
    });

    await browser.close();
    let bad = 0;
    for (const [name, ok] of Object.entries(r)) { console.log(`  ${ok ? '✓' : '✗'} ${name}`); if (!ok) bad++; }
    console.log(`真实 Chromium 交互：${Object.keys(r).length - bad}/${Object.keys(r).length}`);
    process.exit(bad ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
