import UIKit
import Capacitor
import WebKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene else { return }

        window = UIWindow(windowScene: windowScene)
        window?.rootViewController = RPBridgeViewController()
        window?.makeKeyAndVisible()

        SceneDelegateProxy.shared.scene(scene, willConnectTo: session, options: connectionOptions)
    }

    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        SceneDelegateProxy.shared.scene(scene, openURLContexts: URLContexts)
    }

    func scene(_ scene: UIScene, continue userActivity: NSUserActivity) {
        SceneDelegateProxy.shared.scene(scene, continue: userActivity)
    }
}

// Included in this existing target source file so no pbxproj registration is needed.
final class RPBridgeViewController: CAPBridgeViewController, WKScriptMessageHandler {
    private var generating = false
    private var backgroundTask: UIBackgroundTaskIdentifier = .invalid

    override func capacitorDidLoad() {
        super.capacitorDidLoad()
        webView?.configuration.userContentController.add(self, name: "rphubGeneration")
        NotificationCenter.default.addObserver(self, selector: #selector(didEnterBackground),
            name: UIApplication.didEnterBackgroundNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(willEnterForeground),
            name: UIApplication.willEnterForegroundNotification, object: nil)
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "rphubGeneration",
              let payload = message.body as? [String: Any],
              let active = payload["active"] as? Bool else { return }
        generating = active
        if !active { endBackgroundTime() }
        else if UIApplication.shared.applicationState == .background { didEnterBackground() }
    }

    @objc private func didEnterBackground() {
        guard generating, backgroundTask == .invalid else { return }
        backgroundTask = UIApplication.shared.beginBackgroundTask(withName: "FinishChatReply") { [weak self] in
            // Expiration must end the assertion, never cancel a partially received reply.
            self?.endBackgroundTime()
        }
    }

    @objc private func willEnterForeground() { endBackgroundTime() }

    private func endBackgroundTime() {
        guard backgroundTask != .invalid else { return }
        let task = backgroundTask
        backgroundTask = .invalid
        UIApplication.shared.endBackgroundTask(task)
    }
}
