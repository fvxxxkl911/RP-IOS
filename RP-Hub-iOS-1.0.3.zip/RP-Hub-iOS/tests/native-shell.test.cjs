/* Deterministic behaviour tests for the native shell bridge.
 *
 * The bridge is a classic script with no imports, so it can be executed in a
 * fresh vm context with a minimal DOM/Capacitor stub. Every test drives the
 * registered listeners directly: no real WebView, no timers, no network.
 *
 * Focus of this suite: the "composer appears, keyboard follows a beat later"
 * lag under frequent type -> send -> type loops.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const BRIDGE = fs.readFileSync(
    path.join(__dirname, '..', 'public', 'assets', 'js', 'capacitor-bridge.js'),
    'utf8'
);

// --- tiny DOM -------------------------------------------------------------
function el(tag, className, parent) {
    const node = {
        tagName: tag.toUpperCase(),
        className: className || '',
        nodeType: 1,
        parentNode: parent || null,
        style: {},
        dataset: {},
        attributes: {},
        disabled: false,
        readOnly: false,
        isContentEditable: false,
        focused: false,
        focusCalls: 0,
        focus() { this.focusCalls += 1; this.focused = true; },
        hasAttribute(n) { return Object.prototype.hasOwnProperty.call(this.attributes, n); },
        getAttribute(n) { return this.attributes[n]; },
        setAttribute(n, v) { this.attributes[n] = String(v); },
        removeAttribute(n) { delete this.attributes[n]; },
        set type(v) { this._type = v; },
        get type() { return this._type || 'text'; },
        closest(sel) {
            const parts = String(sel).split(',').map(s => s.trim()).filter(Boolean);
            for (let cur = this; cur; cur = cur.parentNode) {
                for (const p of parts) {
                    if (p.startsWith('.')) {
                        if (cur.className.split(/\s+/).includes(p.slice(1))) return cur;
                    } else if (cur.tagName === p.toUpperCase()) {
                        return cur;
                    }
                }
            }
            return null;
        },
        querySelector() { return null; }
    };
    return node;
}

function makeContext({ native = true, plugins = {} } = {}) {
    const listeners = {};
    const classes = new Set();
    const injected = [];

    const root = el('html');
    root.classList = {
        add: n => classes.add(n),
        remove: n => classes.delete(n),
        contains: n => classes.has(n),
        toggle: (n, on) => (on ? classes.add(n) : classes.delete(n))
    };
    root.style.setProperty = () => {};
    root.style.removeProperty = () => {};

    const head = { appendChild(node) { injected.push(node); } };
    const document = {
        documentElement: root,
        head,
        body: el('body'),
        readyState: 'complete',
        activeElement: null,
        hidden: false,
        addEventListener(type, fn, capture) {
            (listeners[type] ||= []).push({ fn, capture: !!capture });
        },
        removeEventListener() {},
        dispatchEvent() { return true; },
        createElement(tag) { return { tagName: tag.toUpperCase(), id: '', textContent: '', style: {} }; },
        querySelectorAll() { return []; },
        querySelector() { return null; },
        getElementById() { return null; }
    };

    function CSSStyleDeclaration() {}
    CSSStyleDeclaration.prototype.setProperty = function () {};
    CSSStyleDeclaration.prototype.removeProperty = function () { return ''; };

    const timers = [];
    const sandbox = {
        window: {
            Capacitor: {
                isNativePlatform: () => native,
                getPlatform: () => (native ? 'ios' : 'web'),
                Plugins: plugins
            },
            fetch: function fetch() {},
            innerHeight: 874,
            innerWidth: 402
        },
        location: { protocol: native ? 'capacitor:' : 'https:', origin: 'capacitor://localhost', pathname: '/index.html' },
        document,
        CSSStyleDeclaration,
        MutationObserver: function () { this.observe = () => {}; },
        KeyboardEvent: function () {},
        Event: function () {},
        setTimeout: (fn, ms) => { timers.push({ fn, ms }); return timers.length; },
        clearTimeout: () => {},
        requestAnimationFrame: fn => { timers.push({ fn, ms: 0 }); return timers.length; },
        cancelAnimationFrame: () => {},
        console,
        Object, String, Math, Date, JSON, RegExp, Array, Function, Boolean, Number, Error,
        CSS: undefined
    };
    sandbox.window.window = sandbox.window;
    sandbox.window.document = document;
    sandbox.globalThis = sandbox;

    const ctx = vm.createContext(sandbox);
    vm.runInContext(BRIDGE, ctx, { filename: 'capacitor-bridge.js' });

    return {
        root, document, listeners, classes, injected, timers,
        css: injected.map(n => n.textContent).join('\n'),
        fire(type, event) {
            const list = listeners[type] || [];
            for (const l of list) l.fn(event);
            return list;
        }
    };
}

function composerTree() {
    const area = el('div', 'input-area-mobile');
    const island = el('div', 'input-island', area);
    const textarea = el('textarea', 'island-input', island);
    const toolbar = el('div', 'island-toolbar', island);
    const send = el('button', 'island-send', toolbar);
    const quick = el('button', 'island-button', toolbar);
    const outside = el('button', 'settings-button');
    return { area, island, textarea, send, quick, outside };
}

// --- CSS invariants ------------------------------------------------------
test('native: backdrop-filter suppression is a constant rule, not toggled on the keyboard frame', () => {
    const c = makeContext();
    assert.match(c.css, /html\[data-rphub-native="true"\] \*\{-webkit-backdrop-filter:none!important;backdrop-filter:none!important\}/);
    assert.doesNotMatch(c.css, /rphub-keyboard-active \*\{-webkit-backdrop-filter/,
        'a universal selector must never be switched at keyboardWillShow (full-tree style recalc)');
    assert.match(c.css, /rphub-keyboard-active :is\(/,
        'the narrow transition/animation switch must remain keyboard-scoped');
    assert.equal(c.root.dataset.rphubNative, 'true');
});

test('native: the 16 Pro geometry and keyboard padding are untouched by this change', () => {
    const c = makeContext();
    for (const needle of [
        '--rphub-safe-bottom:50px', '--rphub-safe-side:16px',
        '--rphub-corner-input:26px', '--rphub-corner-nav:34px',
        '.app-navigation-layer{display:flex', 'padding-bottom:8px!important'
    ]) assert.ok(c.css.includes(needle), `missing CSS invariant: ${needle}`);
});

test('web (non-native): the bridge is a complete no-op', () => {
    const c = makeContext({ native: false });
    assert.equal(c.injected.length, 0, 'no CSS may be injected in a browser');
    assert.equal(c.root.dataset.rphubNative, undefined);
    for (const type of ['mousedown', 'focusout', 'click', 'visibilitychange']) {
        assert.equal((c.listeners[type] || []).length, 0, `listener ${type} registered in a browser`);
    }
});

// --- the actual fix: keep the keyboard up across turns ---------------------
test('mousedown on a composer button is cancelled (textarea keeps first responder)', () => {
    const c = makeContext();
    const t = composerTree();
    let prevented = 0;
    const md = { target: t.send, button: 0, defaultPrevented: false, preventDefault() { prevented += 1; this.defaultPrevented = true; } };
    c.fire('mousedown', md);
    assert.equal(prevented, 1, 'composer button mousedown must be cancelled');

    const md2 = { target: t.quick, button: 0, defaultPrevented: false, preventDefault() { prevented += 1; this.defaultPrevented = true; } };
    c.fire('mousedown', md2);
    assert.equal(prevented, 2, 'every composer toolbar button must be covered');
});

test('mousedown outside the composer is NOT cancelled (user can still dismiss)', () => {
    const c = makeContext();
    const t = composerTree();
    let prevented = 0;
    const ev = { target: t.outside, button: 0, defaultPrevented: false, preventDefault() { prevented += 1; } };
    c.fire('mousedown', ev);
    assert.equal(prevented, 0);

    const rightClick = { target: t.send, button: 2, defaultPrevented: false, preventDefault() { prevented += 1; } };
    c.fire('mousedown', rightClick);
    assert.equal(prevented, 0, 'non-primary buttons must be ignored');

    const alreadyHandled = { target: t.send, button: 0, defaultPrevented: true, preventDefault() { prevented += 1; } };
    c.fire('mousedown', alreadyHandled);
    assert.equal(prevented, 0, 'must not fight another handler that already prevented default');
});

test('focusout fallback only steals focus back for composer buttons', () => {
    const c = makeContext();
    const t = composerTree();
    // The focusout listeners include the pre-existing stale-class guard; find
    // the one that calls field.focus() by observing focusCalls.
    c.fire('focusout', { target: t.textarea, relatedTarget: t.send });
    assert.equal(t.textarea.focusCalls, 1, 'focus should be returned when a composer button stole it');

    const t2 = composerTree();
    c.fire('focusout', { target: t2.textarea, relatedTarget: t2.outside });
    assert.equal(t2.textarea.focusCalls, 0, 'must not trap focus when the user taps elsewhere');

    const t3 = composerTree();
    c.fire('focusout', { target: t3.textarea, relatedTarget: null });
    assert.equal(t3.textarea.focusCalls, 0, 'null relatedTarget (typical iOS) must be left alone');
});

// --- keyboard class lifecycle still works -----------------------------------
test('keyboardWillShow / keyboardDidHide toggle the performance class', () => {
    const kbHandlers = {};
    const Keyboard = {
        addListener: (name, fn) => { (kbHandlers[name] ||= []).push(fn); }
    };
    const c = makeContext({ plugins: { Keyboard } });
    assert.ok(kbHandlers.keyboardWillShow, 'keyboardWillShow listener missing');
    kbHandlers.keyboardWillShow.forEach(fn => fn({ keyboardHeight: 300 }));
    assert.equal(c.classes.has('rphub-keyboard-active'), true);
    (kbHandlers.keyboardDidHide || []).forEach(fn => fn());
    assert.equal(c.classes.has('rphub-keyboard-active'), false, 'class must be cleared on hide');
});

test('keyboard events must not write inline styles on <html>', () => {
    const kbHandlers = {};
    const Keyboard = { addListener: (name, fn) => { (kbHandlers[name] ||= []).push(fn); } };
    const c = makeContext({ plugins: { Keyboard } });
    let writes = 0;
    c.root.style.setProperty = () => { writes += 1; };
    kbHandlers.keyboardWillShow.forEach(fn => fn({ keyboardHeight: 300 }));
    (kbHandlers.keyboardWillHide || []).forEach(fn => fn());
    (kbHandlers.keyboardDidHide || []).forEach(fn => fn());
    assert.equal(writes, 0, 'an inline style write on <html> costs an extra style recalc per keyboard frame');
});

test('chat scroll is not anchored/chained while the native keyboard resizes the frame', () => {
    const c = makeContext();
    assert.match(c.css, /\.chat-scroll\{overscroll-behavior:contain!important;overflow-anchor:none!important\}/,
        'chat scroll container must opt out of WebKit scroll anchoring on native');
});
