/* RP-Hub native shell bridge (1.0.4).
 *
 * Classic script, no imports: it is copied verbatim from publicDir and injected
 * into every page by vite.config.js. In a plain browser it is a complete no-op,
 * so the web release keeps its original behaviour byte-for-byte.
 *
 * Scope is deliberately limited to "shell" concerns. It never changes request
 * routing, model selection, storage or any business logic.
 */
(function () {
    'use strict';

    var C = window.Capacitor;
    var plugins = (C && C.Plugins) || {};
    var native = !!(C && typeof C.isNativePlatform === 'function' && C.isNativePlatform());

    var info = {
        native: native,
        platform: (C && typeof C.getPlatform === 'function' && C.getPlatform()) || 'web',
        scheme: location.protocol.replace(/:$/, ''),
        origin: location.origin,
        plugins: Object.keys(plugins).sort(),
        // True when CapacitorHttp has replaced window.fetch with the native bridge.
        // Streaming SSE (api-utils.js uses response.body.getReader()) is then degraded.
        fetchPatched: native && !/^\s*function fetch\s*\(/.test(String(window.fetch))
    };

    try { Object.freeze(info); } catch (_) { }
    window.RPHubNative = info;

    if (!native) return;

    // Enables the native-only CSS below (only on a real device).
    var rootEl = document.documentElement;
    rootEl.dataset.rphubNative = 'true';

    // ----------------------------------------------------------------------
    // iOS shell polish. Injected from JS rather than from the built HTML so the
    // three business pages keep their web logic; only the version label differs
    // (1.0.4).
    // ----------------------------------------------------------------------
    var SHELL_CSS = [
        // (1) Secure keyboard. iOS forces a password-only keyboard on
        //     input[type=password]: third-party keyboards are disabled, the
        //     paste/ AutoFill bar becomes "此 App 的密码", and the key is offered
        //     to the keychain. Secret fields are converted to plain text inputs
        //     below; this rule keeps the dots without the secure traits.
        'html[data-rphub-native="true"] input[data-rphub-secure]:not([data-rphub-plain]){-webkit-text-security:disc}',
        'html[data-rphub-native="true"] input[data-rphub-secure]{-webkit-appearance:none;appearance:none}',

        // (2) iPhone 16 Pro geometry, expressed as FIXED numbers.
        //
        //     Device: 402 x 874 pt @3x (1206 x 2622 px). Portrait safe-area insets
        //     are top 62 pt / bottom 34 pt (Home Indicator) / sides 0 pt, and the
        //     display corner radius is about 53 pt. StatusBar.overlaysWebView is
        //     false, so the WebView already starts below the status bar: NO top
        //     padding may be added to html/body/#app (that caused the whole-page
        //     downward shift + bottom clipping two builds ago).
        //
        //     Why fixed values and not env(safe-area-inset-*): index.html and
        //     novel/index.html do NOT declare viewport-fit=cover, so in WKWebView
        //     those env() values resolve to 0 while character/diagnostics (which
        //     do declare cover) resolve to 34pt. Relying on env() made the same
        //     composer sit at 12pt on one page and 46pt on another - the measured
        //     "position wanders" symptom. A fixed floor (max with env() only
        //     widens it on devices with a LARGER inset) is deterministic on 16 Pro
        //     and still safe on future/landscape layouts.
        'html[data-rphub-native="true"]{--rphub-safe-bottom:50px;--rphub-safe-top:12px;--rphub-safe-side:16px;--rphub-corner-nav:34px;--rphub-corner-input:26px;--rphub-corner-card:22px;--rphub-corner-control:14px;--rphub-corner-list:18px}',
        // 50px = 34pt Home Indicator inset + 16pt breathing room. Measured before:
        // the island's bottom edge sat only 37px (12.3pt) above the physical
        // screen bottom, i.e. inside the Home Indicator zone / clipped by the
        // lower screen corners. 16pt side margins match Apple's HIG and keep the
        // 26px radius clear of the rounded display corners.
        'html[data-rphub-native="true"] .input-area-mobile{padding-left:max(var(--rphub-safe-side),env(safe-area-inset-left,0px))!important;padding-right:max(var(--rphub-safe-side),env(safe-area-inset-right,0px))!important;padding-bottom:max(var(--rphub-safe-bottom),calc(env(safe-area-inset-bottom,0px) + 16px))!important}',
        'html[data-rphub-native="true"] .input-island{border-radius:var(--rphub-corner-input)!important}',
        'html[data-rphub-native="true"],html[data-rphub-native="true"] body,html[data-rphub-native="true"] #app{height:100%!important;min-height:0!important}',
        'html[data-rphub-native="true"] :is(.app-main,.chat-view-root){height:100%!important;min-height:0!important}',
        'html[data-rphub-native="true"] .input-area-mobile{bottom:0!important}',

        'html[data-rphub-native="true"] .app-navigation-panel{border-radius:var(--rphub-corner-nav)!important}',
        'html[data-rphub-native="true"] .settings-card{border-radius:var(--rphub-corner-card)!important}',
        'html[data-rphub-native="true"] .settings-view .settings-control{border-radius:var(--rphub-corner-control)!important}',
        'html[data-rphub-native="true"] .list-card{border-radius:var(--rphub-corner-list)!important}',
        // Continuous ("squircle") corners are an iOS signature. Progressive:
        // older WebKit simply ignores the rule and keeps the plain radius.
        '@supports (corner-shape:squircle){html[data-rphub-native="true"] :is(.input-island,.app-navigation-panel,.settings-card,.settings-view .settings-control,.list-card){corner-shape:squircle}}',

        // (2b) One stable position for the RP HUB sheet in EVERY view.
        //      ui-components.js centers the panel only for "online" views; for
        //      chat/settings it computes an inline top/left from window.innerHeight
        //      and the trigger rect. With the visual-viewport vars frozen, that
        //      snapshot landed 87pt lower (panel bottom at 12pt vs 99pt on the
        //      device), so the sheet visibly jumped and its footer was clipped.
        //      flex-centering + a safe-area padded box makes it identical in all
        //      views; !important overrides the inline style the component writes.
        'html[data-rphub-native="true"] .app-navigation-layer{display:flex!important;align-items:center!important;justify-content:center!important;padding:var(--rphub-safe-top) var(--rphub-safe-side) var(--rphub-safe-bottom)!important}',
        'html[data-rphub-native="true"] .app-navigation-panel{position:relative!important;top:auto!important;left:auto!important;max-height:100%!important;overflow-y:auto!important}',

        // (3) Keyboard animation. Keyboard.resize="native" shrinks the WKWebView
        //     itself. Dropping transitions, live blur and backdrop filters for the
        //     ~0.25 s frame animation removes the frame-by-frame relayout that
        //     made the composer stutter. While the keyboard covers the lower
        //     screen the Home Indicator inset is not needed; a small fixed 8px
        //     gap replaces the old 0 (a stale keyboard-active class can then never
        //     push the composer back under the physical bottom edge).
        //
        //     The universal backdrop-filter rule is deliberately NOT keyed off
        //     .rphub-keyboard-active: adding a `*` + !important rule at the exact
        //     frame the keyboard appears invalidates the style of every node in
        //     the tree (a chat log can hold hundreds of messages). As a constant
        //     native-shell rule it gives the same result with zero style
        //     recalculation on the animation's first frame. The mobile stylesheet
        //     already disables backdrop-filter below 768px, so this only guards
        //     the pages that do not hit that media query.
        'html.rphub-keyboard-active :is(.app-main,.chat-view-root,.input-area-mobile,.input-island,.char-bg-blur,.app-navigation-panel){transition:none!important;animation:none!important}',
        'html.rphub-keyboard-active .char-bg-blur{filter:none!important;will-change:auto!important}',
        'html[data-rphub-native="true"] *{-webkit-backdrop-filter:none!important;backdrop-filter:none!important}',
        'html[data-rphub-native="true"].rphub-keyboard-active .input-area-mobile{padding-bottom:8px!important}',
        // The chat log manages its own scroll position in JS. Disabling scroll
        // anchoring and chaining stops WebKit from adjusting scrollTop on every
        // frame while the native keyboard resizes the WebView.
        'html[data-rphub-native="true"] .chat-scroll{overscroll-behavior:contain!important;overflow-anchor:none!important}',
        // Transform mode (resize: none + CSS transform). Active when
        // 'rphub-kb-transform' class is on <html>. The composer is pushed up
        // by --rphub-kb-h and the chat gets extra bottom padding so content
        // isn't hidden behind the keyboard.
        'html.rphub-kb-transform .input-area-mobile{transform:translateY(calc(-1 * var(--rphub-kb-h,0px)))!important;transition:transform 250ms cubic-bezier(.32,.72,0,1)!important}',
        'html.rphub-kb-transform .chat-scroll{padding-bottom:calc(13rem + var(--rphub-kb-h,0px))!important}'
    ].join('\n');

    var styleEl = document.createElement('style');
    styleEl.id = 'rphub-native-shell-css';
    styleEl.textContent = SHELL_CSS;
    (document.head || rootEl).appendChild(styleEl);

    // ----------------------------------------------------------------------
    // Secret fields -> plain text fields, masked with -webkit-text-security.
    // Covers every page and every Vue-rendered dialog (settings API Key,
    // Tavily key, diagnostics key, ...). No business script is modified.
    // ----------------------------------------------------------------------
    var SECURE_SEL = 'input[type="password"], input[data-rphub-secure]';

    var normalizeSecureFields = function () {
        var fields = document.querySelectorAll(SECURE_SEL);
        for (var i = 0; i < fields.length; i++) {
            var el = fields[i];
            if (!el.hasAttribute('data-rphub-secure')) {
                el.setAttribute('data-rphub-secure', '');
                el.setAttribute('autocomplete', 'off');
                el.setAttribute('autocorrect', 'off');
                el.setAttribute('autocapitalize', 'off');
                el.setAttribute('spellcheck', 'false');
            }
            // Vue rebinds :type as the eye button toggles. Always force it back;
            // visibility is driven by the button's aria-pressed, not by type.
            if (el.type !== 'text') el.type = 'text';
        }
        var boxes = document.querySelectorAll('.secret-input');
        for (var j = 0; j < boxes.length; j++) {
            var input = boxes[j].querySelector('input[data-rphub-secure]');
            if (!input) continue;
            var btn = boxes[j].querySelector('.secret-input__actions button[aria-pressed]');
            var plain = !!btn && (btn.getAttribute('aria-pressed') === 'true' || btn.getAttribute('title') === '隐藏');
            if (plain) input.setAttribute('data-rphub-plain', '');
            else input.removeAttribute('data-rphub-plain');
        }
    };

    normalizeSecureFields();
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', normalizeSecureFields, { once: true });
    }
    try {
        var secureObserver = new MutationObserver(function (records) {
            for (var i = 0; i < records.length; i++) {
                var r = records[i];
                if (r.type === 'childList' && (r.addedNodes.length || r.removedNodes.length)) {
                    normalizeSecureFields();
                    return;
                }
                if (r.type === 'attributes' &&
                    (r.attributeName === 'type' || r.attributeName === 'aria-pressed' || r.attributeName === 'title')) {
                    normalizeSecureFields();
                    return;
                }
            }
        });
        secureObserver.observe(rootEl, {
            subtree: true,
            childList: true,
            attributes: true,
            attributeFilter: ['type', 'aria-pressed', 'title']
        });
    } catch (_) { /* MutationObserver unavailable: static fields were already converted */ }

    // ----------------------------------------------------------------------
    // Native keyboard resize is the sole layout owner. Do not monkey-patch
    // CSSStyleDeclaration: it also intercepts unrelated app/theme code.
    // ----------------------------------------------------------------------
    rootEl.style.removeProperty('--app-visual-height');
    rootEl.style.removeProperty('--keyboard-inset');
    rootEl.style.removeProperty('--chat-bg-height');

    // Capacitor only boots index.html, so diagnostics.html needs a reachable
    // entry. This button exists ONLY in a native container; browsers never see it.
    // Device validation is done (all checks green), so the entry is off by default.
    // Set it back to true if you ever need to re-run the network/SSE checks.
    var SHOW_DIAGNOSTICS_ENTRY = false;
    if (SHOW_DIAGNOSTICS_ENTRY && !/diagnostics\.html/.test(location.pathname)) {
        var addDiagnosticsEntry = function () {
            if (!document.body || document.getElementById('rphub-diag-entry')) return;
            var b = document.createElement('button');
            b.id = 'rphub-diag-entry';
            b.type = 'button';
            b.textContent = '诊断';
            b.setAttribute('aria-label', '打开真机连通性自检');
            b.style.cssText = 'position:fixed;left:8px;bottom:calc(8px + env(safe-area-inset-bottom,0px));'
                + 'z-index:2147483000;padding:5px 9px;font-size:11px;line-height:1.2;border-radius:8px;'
                + 'border:1px solid rgba(127,127,127,.45);background:rgba(255,255,255,.72);color:#374151;'
                + 'cursor:pointer;opacity:.75';
            b.addEventListener('click', function () { location.href = '/diagnostics.html'; });
            document.body.appendChild(b);
        };
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', addDiagnosticsEntry, { once: true });
        } else {
            addDiagnosticsEntry();
        }
    }

    try {
        if (plugins.StatusBar) plugins.StatusBar.setOverlaysWebView({ overlays: false });
    } catch (_) { /* optional plugin */ }

    try {
        if (plugins.SplashScreen) plugins.SplashScreen.hide();
    } catch (_) { /* optional plugin */ }

    // Keyboard state: performance class only. Layout itself is owned by
    // Keyboard.resize="native" (capacitor.config.json); the black band beside
    // the keyboard is fixed by Keyboard.autoBackdropColor="auto".
    // Do not write --rphub-keyboard-height: nothing consumes it, and an inline
    // style write on <html> costs an extra style invalidation per keyboard event.
    try {
        if (plugins.Keyboard && plugins.Keyboard.addListener) {
            plugins.Keyboard.addListener('keyboardWillShow', function (e) {
                rootEl.classList.add('rphub-keyboard-active');
                // Transform mode: expose the keyboard height as a CSS variable so
                // the composer can be pushed up with a compositor-only transform.
                if (rootEl.classList.contains('rphub-kb-transform')) {
                    rootEl.style.setProperty('--rphub-kb-h', (e.keyboardHeight || 0) + 'px');
                }
            });
            var onKeyboardHide = function () {
                rootEl.classList.remove('rphub-keyboard-active');
                rootEl.style.removeProperty('--rphub-kb-h');
            };
            plugins.Keyboard.addListener('keyboardWillHide', onKeyboardHide);
            plugins.Keyboard.addListener('keyboardDidHide', onKeyboardHide);
            // WKWebView sometimes skips keyboardWillHide/DidHide when the
            // keyboard only changes height (e.g. emoji <-> QWERTY). A stale
            // class would keep the 8px composer padding forever. Belt-and-
            // braces: clear it shortly after focus leaves every editable field.
            var maybeClearKeyboardActive = function () {
                setTimeout(function () {
                    var a = document.activeElement;
                    var editing = a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA' || a.isContentEditable);
                    if (!editing) onKeyboardHide();
                }, 320);
            };
            document.addEventListener('focusout', maybeClearKeyboardActive, true);
            document.addEventListener('visibilitychange', function () {
                if (!document.hidden) maybeClearKeyboardActive();
            });
        }
    } catch (_) { /* optional plugin */ }

    // ----------------------------------------------------------------------
    // (4) Keep the keyboard raised across a whole conversation.
    //
    //     This is the fix for the "composer appears, keyboard arrives a beat
    //     later" lag being repeated on every single reply. On iOS, tapping
    //     ANY <button> moves first responder off the <textarea>, so UIKit
    //     dismisses the keyboard. The next tap on the composer has to raise it
    //     again -- one more full ~0.25 s animation + the Web/UIKit phase gap,
    //     per message, for as long as the user keeps chatting. A single
    //     keyboard show is barely noticeable; dozens of them are what make
    //     frequent replying feel laggy.
    //
    //     Cancelling the default focus transfer on mousedown (capture phase,
    //     before Vue's handlers) keeps the textarea as first responder; click
    //     still fires normally, so send / stop / image / quick-panel buttons
    //     behave exactly as before. Only composer buttons are touched -- the
    //     message list, modals and settings fields still dismiss the keyboard.
    //
    //     Set KEEP_COMPOSER_FOCUS = false to restore the stock behaviour.
    // ----------------------------------------------------------------------
    var KEEP_COMPOSER_FOCUS = true;
    if (KEEP_COMPOSER_FOCUS) {
        var COMPOSER_SCOPE = '.input-area-mobile, .input-island';
        var isComposerButton = function (node) {
            if (!node || node.nodeType !== 1 || typeof node.closest !== 'function') return false;
            var btn = node.closest('button');
            return !!(btn && typeof btn.closest === 'function' && btn.closest(COMPOSER_SCOPE));
        };
        document.addEventListener('mousedown', function (event) {
            if (event.defaultPrevented || event.button !== 0) return;
            if (!isComposerButton(event.target)) return;
            event.preventDefault();
        }, true);
        // Belt-and-braces: some WebKit builds move first responder before the
        // synthetic mousedown is delivered. Only give focus back when it went
        // to another composer button, never when the user tapped elsewhere.
        document.addEventListener('focusout', function (event) {
            var field = event.target;
            if (!field || field.tagName !== 'TEXTAREA' || !isComposerButton(event.relatedTarget)) return;
            try { field.focus({ preventScroll: true }); } catch (_) { try { field.focus(); } catch (_2) { } }
        }, true);
    }

    // iOS has no Escape key and no hardware back button. Tapping the dimmed
    // backdrop dispatches Escape so the existing close handlers still work.
    var dispatchEscape = function () {
        document.dispatchEvent(new KeyboardEvent('keydown', {
            key: 'Escape', code: 'Escape', bubbles: true
        }));
    };
    document.addEventListener('click', function (event) {
        var target = event.target;
        if (!target || !target.classList || !target.classList.contains('app-modal-overlay')) return;
        dispatchEscape();
    }, true);

    // Android hardware back (no-op on iOS, kept so one shell serves both).
    try {
        if (plugins.App && plugins.App.addListener) {
            plugins.App.addListener('backButton', function () {
                if (document.querySelector('.app-modal-overlay')) {
                    dispatchEscape();
                    return;
                }
                try { plugins.App.exitApp(); } catch (_) { }
            });
        }
    } catch (_) { /* optional plugin */ }
})();
