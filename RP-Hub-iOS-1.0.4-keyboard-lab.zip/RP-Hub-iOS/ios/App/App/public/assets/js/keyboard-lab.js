/* RP-Hub Keyboard Lab (diagnostic).
 *
 * Runs ONLY in native shell (isNativePlatform === true). In a browser it's a
 * complete no-op. Exposed as window.RPHubKbLab for console / HUD interaction.
 *
 * Features:
 * - Timestamped log of keyboardWillShow/WillHide/DidShow/DidHide +
 *   visualViewport/innerHeight/composer rect samples each rAF frame for ~1.2s
 * - Runtime mode switch: "native" (default, Keyboard.resize="native") vs
 *   "transform" (Keyboard.resize="none" + CSS transform on composer)
 * - Floating HUD chip to open/close panel, copy log, clear log
 */
(function () {
    'use strict';
    if (!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform())) return;

    var Keyboard = (window.Capacitor.Plugins || {}).Keyboard;
    if (!Keyboard) return;

    var state = {
        mode: 'native',              // 'native' | 'transform'
        log: [],                     // array of {t, type, kbH, vh, ih, compTop, compH, note}
        sampling: false,
        sampleTimer: 0,
        sampleFrames: 0,
        willShowTime: 0,
        didShowTime: 0,
        willHideTime: 0,
        didHideTime: 0,
        firstVhChangeTime: 0,
        firstComposerMoveTime: 0,
        hud: null,
        panel: null,
        lastComposerTop: null,
        composerEl: null,
    };

    function now() { return performance.now(); }
    function log(type, extra) {
        var comp = state.composerEl ? state.composerEl.getBoundingClientRect() : null;
        var entry = {
            t: now(),
            type: type,
            kbH: extra && extra.keyboardHeight,
            vh: window.visualViewport ? window.visualViewport.height : null,
            ih: window.innerHeight,
            compTop: comp ? comp.top : null,
            compH: comp ? comp.height : null,
            note: extra && extra.note,
        };
        state.log.push(entry);
        if (state.panel) renderPanel();
    }

    function findComposer() {
        return document.querySelector('.input-area-mobile') || document.querySelector('.input-island');
    }

    function sampleLoop() {
        if (!state.sampling) return;
        var comp = state.composerEl ? state.composerEl.getBoundingClientRect() : null;
        var moved = comp && state.lastComposerTop !== null && Math.abs(comp.top - state.lastComposerTop) > 0.5;
        if (moved && !state.firstComposerMoveTime) state.firstComposerMoveTime = now();
        state.lastComposerTop = comp ? comp.top : null;
        log('rAF', {});
        state.sampleFrames++;
        if (state.sampleFrames < 72) { // ~1.2s @ 60fps
            state.sampleTimer = requestAnimationFrame(sampleLoop);
        } else {
            state.sampling = false;
        }
    }

    function startSampling(trigger) {
        state.sampling = true;
        state.sampleFrames = 0;
        state.lastComposerTop = null;
        state.firstComposerMoveTime = 0;
        state.composerEl = findComposer();
        if (state.sampleTimer) cancelAnimationFrame(state.sampleTimer);
        state.sampleTimer = requestAnimationFrame(sampleLoop);
        log('sample:start', { note: trigger });
    }

    function onWillShow(e) {
        state.willShowTime = now();
        if (state.firstVhChangeTime === 0) state.firstVhChangeTime = state.willShowTime;
        log('kbWillShow', { keyboardHeight: e && e.keyboardHeight });
        startSampling('kbWillShow');
    }
    function onDidShow(e) {
        state.didShowTime = now();
        log('kbDidShow', { keyboardHeight: e && e.keyboardHeight });
    }
    function onWillHide() {
        state.willHideTime = now();
        log('kbWillHide', {});
        startSampling('kbWillHide');
    }
    function onDidHide() {
        state.didHideTime = now();
        log('kbDidHide', {});
    }

    function setMode(newMode) {
        if (newMode === state.mode) return;
        state.mode = newMode;
        if (newMode === 'transform') {
            // Switch native resize to 'none' and enable CSS transform mode.
            Keyboard.setResizeMode({ mode: 'none' }).catch(function () {});
            document.documentElement.classList.add('rphub-kb-transform');
        } else {
            Keyboard.setResizeMode({ mode: 'native' }).catch(function () {});
            document.documentElement.classList.remove('rphub-kb-transform');
            document.documentElement.style.removeProperty('--rphub-kb-h');
        }
        log('mode', { note: newMode });
        renderPanel();
    }

    // --- HUD ---
    function createHUD() {
        if (state.hud) return;
        var hud = document.createElement('div');
        hud.id = 'rphub-kb-hud';
        hud.innerHTML = '⌨ LAB';
        Object.assign(hud.style, {
            position: 'fixed', top: '8px', left: '8px', zIndex: '2147483647',
            padding: '4px 8px', borderRadius: '4px',
            background: 'rgba(0,0,0,0.7)', color: '#fff', fontSize: '11px',
            fontFamily: 'monospace', cursor: 'pointer', userSelect: 'none',
        });
        hud.addEventListener('click', togglePanel);
        document.body.appendChild(hud);
        state.hud = hud;
    }

    function togglePanel() {
        if (state.panel) {
            state.panel.remove();
            state.panel = null;
        } else {
            createPanel();
        }
    }

    function createPanel() {
        var panel = document.createElement('div');
        panel.id = 'rphub-kb-panel';
        Object.assign(panel.style, {
            position: 'fixed', top: '40px', left: '8px', right: '8px', maxHeight: '60vh',
            zIndex: '2147483647', overflow: 'auto',
            background: 'rgba(10,10,10,0.95)', color: '#ddd',
            fontSize: '10px', fontFamily: 'monospace', lineHeight: '1.4',
            padding: '8px', borderRadius: '6px', border: '1px solid #444',
        });
        var html = '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:6px;">';
        html += '<button data-cmd="mode:native" style="flex:1;padding:4px;border:none;background:#333;color:#fff;border-radius:3px;">native</button>';
        html += '<button data-cmd="mode:transform" style="flex:1;padding:4px;border:none;background:#333;color:#fff;border-radius:3px;">transform</button>';
        html += '<button data-cmd="copy" style="flex:1;padding:4px;border:none;background:#256;color:#fff;border-radius:3px;">复制日志</button>';
        html += '<button data-cmd="clear" style="flex:1;padding:4px;border:none;background:#622;color:#fff;border-radius:3px;">清除</button>';
        html += '<button data-cmd="close" style="flex:1;padding:4px;border:none;background:#555;color:#fff;border-radius:3px;">关闭</button>';
        html += '</div><pre style="margin:0;white-space:pre-wrap;word-break:break-all;">' + formatLog() + '</pre>';
        panel.innerHTML = html;
        panel.addEventListener('click', function (e) {
            var btn = e.target.closest('button[data-cmd]');
            if (!btn) return;
            var cmd = btn.getAttribute('data-cmd');
            if (cmd.startsWith('mode:')) setMode(cmd.slice(5));
            else if (cmd === 'copy') copyLog();
            else if (cmd === 'clear') { state.log = []; log('cleared', {}); }
            else if (cmd === 'close') { panel.remove(); state.panel = null; }
            else if (cmd === 'sample') startSampling('manual');
        });
        document.body.appendChild(panel);
        state.panel = panel;
    }

    function renderPanel() {
        if (!state.panel) return;
        var pre = state.panel.querySelector('pre');
        if (pre) pre.textContent = formatLog();
        // highlight active mode button
        state.panel.querySelectorAll('button[data-cmd^="mode:"]').forEach(function (b) {
            b.style.background = b.getAttribute('data-cmd').slice(5) === state.mode ? '#256' : '#333';
        });
    }

    function formatLog() {
        if (!state.log.length) return '(empty)';
        var out = [];
        out.push('mode: ' + state.mode);
        out.push('---');
        var base = state.log[0].t;
        state.log.forEach(function (e) {
            var dt = (e.t - base).toFixed(1);
            var comp = e.compTop !== null ? (e.compTop.toFixed(1) + 'x' + e.compH.toFixed(1)) : '—';
            out.push(dt + 'ms  ' + e.type.padEnd(12) +
                (e.kbH !== undefined ? ' kbH=' + e.kbH : '') +
                (e.vh !== null ? ' vh=' + e.vh : '') +
                ' ih=' + e.ih +
                ' comp=' + comp +
                (e.note ? ' #' + e.note : ''));
        });
        if (state.willShowTime && state.firstComposerMoveTime) {
            var lag = (state.firstComposerMoveTime - state.willShowTime).toFixed(1);
            out.push('---');
            out.push('composer lag after kbWillShow: ' + lag + 'ms');
        }
        return out.join('\n');
    }

    function copyLog() {
        var txt = formatLog();
        navigator.clipboard.writeText(txt).then(function () {
            log('copied', { note: state.log.length + ' entries' });
        });
    }

    // Attach listeners
    Keyboard.addListener('keyboardWillShow', onWillShow);
    Keyboard.addListener('keyboardDidShow', onDidShow);
    Keyboard.addListener('keyboardWillHide', onWillHide);
    Keyboard.addListener('keyboardDidHide', onDidHide);

    // Expose API
    window.RPHubKbLab = {
        log: state.log,
        setMode: setMode,
        getMode: function () { return state.mode; },
        copy: copyLog,
        clear: function () { state.log = []; log('cleared', {}); },
        summary: function () {
            if (!state.willShowTime || !state.firstComposerMoveTime) return 'no kbWillShow yet';
            return 'kbWillShow→composer first move: ' + (state.firstComposerMoveTime - state.willShowTime).toFixed(1) + 'ms';
        },
    };

    // Auto-create HUD after DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', createHUD);
    } else {
        createHUD();
    }
})();